//
//  Car.swift
//  Classses and Object
//
//  Created by Meet Thanki on 01/09/19.
//  Copyright © 2019 Meet Thanki. All rights reserved.
//

import Foundation

enum CarType{
    
    case Sedan
    case Coupe
    case Hatchback
    
}

class Car {
    
    var color = "Black"
    var noOfSeats = 5
    var typeOfCar : CarType = .Coupe
    
    //Designated Initializer
    /*init(CustomerChoosenColor: String){
        color = CustomerChoosenColor
    }*/
    
    init() {
        
    }
    
    //Convenience  Initializer
    
    convenience init(customerChosenCar:String){
        self.init()
        color = customerChosenCar
    }
    
    convenience init(customerChosenCar:String, CustomerNoOfSeats:Int){
        self.init()
        color = customerChosenCar
        noOfSeats = CustomerNoOfSeats
    }
    
    // Method
    func drive(){
        print("Car is Moving.")
    }
    
}
