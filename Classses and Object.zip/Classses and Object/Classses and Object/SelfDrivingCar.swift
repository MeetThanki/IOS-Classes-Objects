//
//  SelfDrivingCar.swift
//  Classses and Object
//
//  Created by Meet Thanki on 01/09/19.
//  Copyright © 2019 Meet Thanki. All rights reserved.
//

import Foundation

class SelfDrivingCar : Car{
 
    var destination : String?
    
    override func drive() {

        destination = "Hello im some value"
        print("Driving Towards " + destination!)
        
    }
    
}
