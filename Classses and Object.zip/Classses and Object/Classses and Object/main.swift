//
//  main.swift
//  Classses and Object
//
//  Created by Meet Thanki on 01/09/19.
//  Copyright © 2019 Meet Thanki. All rights reserved.
//

import Foundation


let myCar = Car()
let car3 = Car(customerChosenCar: "Gold")
let car4 = Car(customerChosenCar: "Vibranium",CustomerNoOfSeats:10)
/*
print(myCar.color)
print(myCar.noOfSeats)
print(myCar.typeOfCar)


print(car3.color)
print(car3.noOfSeats)
print(car3.typeOfCar)



print(car4.color)
print(car4.noOfSeats)
print(car4.typeOfCar)
*/

myCar.drive()

let selfCar = SelfDrivingCar()

selfCar.drive()
